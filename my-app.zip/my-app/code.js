var Shoe = "Casual Shoes";
var Weather = ["Sunny","Rainy","Windy","Humid"];
var randWeather = Weather[Math.floor(Math.random() * Weather.length)];
var Degrees = randomNumber(30, 87);
var Time = randomNumber(5, 10);
var Picture = "https://images.vans.com/is/image/Vans/D3HY28-HERO?$583x583$";
var CasualShoes = "https://images.vans.com/is/image/Vans/D3HY28-HERO?$583x583$";
var RainBoots = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpcrHT-Yr6O-urXMxaAKjEnfTQv0yNNgRdgsCx64Z87DJUKqpWmODOv0qD0yBWRMmOqU0:https://hatley-weblinc.netdna-ssl.com/product_images/yellow-navy-matte-rain-boots/RB0YELW345_jpg/pdp_zoom.jpg%3Fc%3D1587588521%26locale%3Den&usqp=CAU";
var InsulatedBoots = "https://images.timberland.com/is/image/timberland/9701R231-HERO?$PDP-FULL-IMAGE$";
var SlipOnShoes = "https://images.vans.com/is/image/Vans/EYEW00-HERO?$583x583$";
updatePicture();
initialUpdate();

function initialUpdate() {
  setText("degrees", "Degrees: " + Degrees + "F");
  setText("time", "Time: " + Time + " am");
  setText("weather", "Weather: " + randWeather);
}

function updatePicture() {
  setProperty("ShoeImage", "image", Picture);
}


onEvent("pickbutton", "click", function( ) {
  setText("congratstext", "Congrats you picked " + Shoe);
  setProperty("congratsimage", "image", Picture);
  setScreen("PickedShoeScreen");
});










onEvent("shoetype", "change", function( ) {
  Shoe = getText("shoetype");
  if (Shoe == "Casual Shoes") {
    Picture = CasualShoes;
    updatePicture();
  }
  if (Shoe == "Rain Boots") {
    Picture = RainBoots;
    updatePicture();
  }
  if (Shoe == "Insulated Boots") {
    Picture = InsulatedBoots;
    updatePicture();
  }
  if (Shoe == "Slip On Shoes") {
    Picture = SlipOnShoes;
    updatePicture();
  }
});
